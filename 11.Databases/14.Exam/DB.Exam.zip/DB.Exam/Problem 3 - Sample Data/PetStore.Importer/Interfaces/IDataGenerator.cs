﻿namespace PetStore.Importer.Interfaces
{
    public interface IDataGenerator
    {
        void Generate();
    }
}
