﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public abstract class DataGenerator : IDataGenerator
    {
        private IRandomDataGenerator random;
        private PetStoreEntities db;
        private int count;

        public DataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
        {
            this.random = randomGenerator;
            this.db = database;
            this.count = numberToGenerate;
        }

        protected IRandomDataGenerator Random
        {
            get { return this.random; }
        }

        protected PetStoreEntities Db
        {
            get { return this.db; }
            set { this.db = value; }
        }

        protected int Count
        {
            get { return this.count; }
        }

        public abstract void Generate();
    }
}
