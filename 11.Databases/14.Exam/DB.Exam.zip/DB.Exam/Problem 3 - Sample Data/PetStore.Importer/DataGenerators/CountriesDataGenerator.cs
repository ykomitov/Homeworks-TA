﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public class CountriesDataGenerator : DataGenerator, IDataGenerator
    {
        public CountriesDataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
            : base(randomGenerator, database, numberToGenerate)
        {
        }

        public override void Generate()
        {
            var uniqueCountryNames = new HashSet<string>();

            while (uniqueCountryNames.Count != this.Count)
            {
                uniqueCountryNames.Add(this.Random.GetRandomStringWithRandomLength(5, 50));
            }

            Console.WriteLine("Adding countries: ");

            int counter = 0;

            foreach (var countryName in uniqueCountryNames)
            {
                var country = new Country
                    {
                        Name = countryName
                    };

                if (counter % 100 == 0)
                {
                    Console.Write("=");
                    this.Db.SaveChanges();
                    this.Db = new PetStoreEntities();
                }

                this.Db.Countries.Add(country);
                counter++;
            }

            this.Db.SaveChanges();
            Console.WriteLine("\r\nCountries added!");
        }
    }
}
