﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public class PetsDataGenerator : DataGenerator, IDataGenerator
    {
        public PetsDataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
            : base(randomGenerator, database, numberToGenerate)
        {
        }

        public override void Generate()
        {
            var listOfSpieciesIdsInDatabase = this.Db.Species.Select(s => s.SpeciesId).ToList();
            var listOfColorIdsInDatabase = this.Db.Colors.Select(c => c.ColorId).ToList();

            Console.WriteLine("Adding pets: ");
            for (int i = 0; i < this.Count; i++)
            {
                if (i >= listOfSpieciesIdsInDatabase.Count)
                {
                    break;
                }

                for (int j = 0; j < 50; j++)
                {
                    var pet = new Pet
                    {
                        SpeciesId = listOfSpieciesIdsInDatabase[i],
                        Birthday = new DateTime(
                            this.Random.GetRandomNumber(2010, 2015),
                            this.Random.GetRandomNumber(1, 8),
                            this.Random.GetRandomNumber(1, 28),
                            this.Random.GetRandomNumber(1, 12),
                            this.Random.GetRandomNumber(1, 59),
                            this.Random.GetRandomNumber(1, 59)),
                        Price = this.Random.GetRandomNumber(5, 2500),
                        ColorId = listOfColorIdsInDatabase[this.Random.GetRandomNumber(0, listOfColorIdsInDatabase.Count - 2)],
                        Breed = this.Random.GetRandomStringWithRandomLength(5, 30)
                    };

                    this.Db.Pets.Add(pet);

                    if (j % 50 == 0)
                    {
                        Console.Write("=");
                        this.Db.SaveChanges();
                        this.Db = new PetStoreEntities();
                    }
                }
            }

            this.Db.SaveChanges();
            Console.WriteLine("\r\nPets added!");
        }
    }
}
