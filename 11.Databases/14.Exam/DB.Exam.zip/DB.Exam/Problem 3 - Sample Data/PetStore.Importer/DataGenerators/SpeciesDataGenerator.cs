﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public class SpeciesDataGenerator : DataGenerator, IDataGenerator
    {
        public SpeciesDataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
            : base(randomGenerator, database, numberToGenerate)
        {
        }

        public override void Generate()
        {
            var uniqueSpeciesNames = new HashSet<string>();

            while (uniqueSpeciesNames.Count != this.Count)
            {
                uniqueSpeciesNames.Add(this.Random.GetRandomStringWithRandomLength(5, 50));
            }

            var countryIdsInTheDatabase = this.Db.Countries.Select(c => c.CountryId).ToList();

            Console.WriteLine("Adding species: ");

            int counter = 0;
            int countryCounter = 0;
            foreach (var speciesName in uniqueSpeciesNames)
            {
                if (countryIdsInTheDatabase.Count == 0)
                {
                    break;
                }

                var species = new Species
                {
                    CountryId = countryIdsInTheDatabase[0],
                    Name = speciesName
                };

                this.Db.Species.Add(species);
                counter++;
                countryCounter++;

                if (countryCounter == 5)
                {
                    countryIdsInTheDatabase.RemoveAt(0);
                    countryCounter = 0;
                }

                if (counter % 100 == 0)
                {
                    Console.Write("=");
                    this.Db.SaveChanges();
                    this.Db = new PetStoreEntities();
                }
            }

            this.Db.SaveChanges();
            Console.WriteLine("\r\nSpecies added!");
        }
    }
}
