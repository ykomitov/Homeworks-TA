﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public class CategoriesDataGenerator : DataGenerator, IDataGenerator
    {
        public CategoriesDataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
            : base(randomGenerator, database, numberToGenerate)
        {
        }

        public override void Generate()
        {
            var uniqueCategoryNames = new HashSet<string>();

            while (uniqueCategoryNames.Count != this.Count)
            {
                uniqueCategoryNames.Add(this.Random.GetRandomStringWithRandomLength(5, 20));
            }

            Console.WriteLine("Adding categories: ");
            foreach (var name in uniqueCategoryNames)
            {
                var category = new Category
                {
                    Name = name
                };

                this.Db.Categories.Add(category);
            }

            this.Db.SaveChanges();
            Console.WriteLine("\r\nCategories added!");
        }
    }
}
