﻿namespace PetStore.Importer.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using PetStore.Data;
    using PetStore.Importer.Interfaces;

    public class ProductDataGenerator : DataGenerator, IDataGenerator
    {
        public ProductDataGenerator(IRandomDataGenerator randomGenerator, PetStoreEntities database, int numberToGenerate)
            : base(randomGenerator, database, numberToGenerate)
        {
        }

        public override void Generate()
        {
            var categoryIdsOfAllCategoriesInTheDb = this.Db.Categories.Select(c => c.CategoryId).OrderBy(a => Guid.NewGuid()).ToList();

            var uniqueProductNames = new HashSet<string>();

            while (uniqueProductNames.Count != this.Count)
            {
                uniqueProductNames.Add(this.Random.GetRandomStringWithRandomLength(5, 25));
            }

            Console.WriteLine("Adding products: ");

            int counter = 0;
            int productCounter = 0;
            foreach (var productName in uniqueProductNames)
            {
                var product = new PetProduct
                {
                    CategoryId = categoryIdsOfAllCategoriesInTheDb[0],
                    Name = productName,
                    Price = this.Random.GetRandomNumber(10, 1000)
                };

                this.Db.PetProducts.Add(product);
                counter++;
                productCounter++;

                if (productCounter == 400)
                {
                    categoryIdsOfAllCategoriesInTheDb.RemoveAt(0);
                    productCounter = 0;
                }

                if (counter % 100 == 0)
                {
                    Console.Write("=");
                    this.Db.SaveChanges();
                    this.Db = new PetStoreEntities();
                }
            }

            this.Db.SaveChanges();
            Console.WriteLine("\r\nProducts added!");
        }
    }
}
