﻿namespace PetStore.ConsoleClient
{
    using System;
    using System.Collections.Generic;
    using PetStore.Data;
    using PetStore.Importer;
    using PetStore.Importer.DataGenerators;
    using PetStore.Importer.Interfaces;

    public class Startup
    {
        public static void Main()
        {
            var random = RandomDataGenerator.Instance;
            var database = new PetStoreEntities();

            var listOfGenerators = new List<IDataGenerator>
                {
                   new CountriesDataGenerator(random, database, 20000),
                   new SpeciesDataGenerator(random, database, 100),
                   new PetsDataGenerator(random, database, 5000),
                   new CategoriesDataGenerator(random, database, 50),
                   new ProductDataGenerator(random, database, 20000)
                };

            foreach (var generator in listOfGenerators)
            {
                generator.Generate();
                database.SaveChanges();
            }
        }
    }
}
