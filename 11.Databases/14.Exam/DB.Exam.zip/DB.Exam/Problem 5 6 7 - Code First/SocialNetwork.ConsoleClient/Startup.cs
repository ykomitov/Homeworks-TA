﻿namespace SocialNetwork.ConsoleClient
{
    using System;
    using System.Data.Entity;
    using System.Linq;
    using SocialNetwork.Data;
    using SocialNetwork.Data.Migrations;
    using SocialNetwork.Models;

    public class Startup
    {
        public static void Main()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<SocialNetworkDbContext, Configuration>());

            var db = new SocialNetworkDbContext();

            var user = new UserProfile
            {
                Username = "dbadmin",
                FirstName = "Pesho",
                LastName = "Ivanov",
                RegistrationDate = new DateTime(2015, 1, 1, 1, 1, 1)
            };

            db.UserProfiles.Add(user);
            db.SaveChanges();

            Console.WriteLine(db.UserProfiles.Count());
        }
    }
}
