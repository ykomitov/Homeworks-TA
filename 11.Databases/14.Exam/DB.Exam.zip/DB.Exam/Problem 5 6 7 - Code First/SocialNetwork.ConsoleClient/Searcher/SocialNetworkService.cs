﻿namespace SocialNetwork.ConsoleClient.Searcher
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using SocialNetwork.Data;

    public class SocialNetworkService : ISocialNetworkService
    {
        public IEnumerable GetUsersAfterCertainDate(int year)
        {
            using (var db = new SocialNetworkDbContext())
            {
                var result = db.UserProfiles
                    .Where(u => u.RegistrationDate > new DateTime(year, 1, 1))
                    .Select(s => new
                    {
                        Username = s.Username,
                        FirstName = s.FirstName,
                        LastName = s.LastName,
                        NumberOfImages = s.Images.Count
                    })
                    .ToList();

                return result;
            }
        }

        public IEnumerable GetPostsByUser(string username)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public IEnumerable GetFriendships(int page = 1, int pageSize = 25)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public IEnumerable GetChatUsers(string username)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}
