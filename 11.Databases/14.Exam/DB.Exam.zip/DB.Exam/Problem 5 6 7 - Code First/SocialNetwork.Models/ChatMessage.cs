﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class ChatMessage
    {
        [Key]
        public int ChatMessageId { get; set; }

        [Required]
        public string Content { get; set; }

        public DateTime SentDate { get; set; }

        public DateTime SeenDate { get; set; }

        public virtual Friendship FriendshipId { get; set; }

        public virtual UserProfile UserProfile { get; set; }
    }
}
