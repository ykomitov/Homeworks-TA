﻿namespace SocialNetwork.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public class Friendship
    {
        [Key]
        public int FriendshipId { get; set; }

        public bool? IsApproved { get; set; }

        public DateTime? DateOfApproval { get; set; }

        [Required]
        public virtual UserProfile FirsUserId { get; set; }

        [Required]
        public virtual UserProfile SecondUserId { get; set; }
    }
}
