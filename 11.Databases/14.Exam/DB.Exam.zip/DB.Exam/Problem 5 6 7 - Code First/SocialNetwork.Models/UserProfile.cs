﻿namespace SocialNetwork.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;

    public class UserProfile
    {
        private ICollection<Image> images;
        private ICollection<ChatMessage> messages;

        public UserProfile()
        {
            this.images = new HashSet<Image>();
        }

        [Key]
        public int UserProfileId { get; set; }

        [Required]
        [MinLength(4)]
        [MaxLength(20)]
        public string Username { get; set; }

        [MinLength(2)]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [MinLength(2)]
        [MaxLength(50)]
        public string LastName { get; set; }

        [Required]
        public DateTime RegistrationDate { get; set; }

        public virtual ICollection<Image> Images
        {
            get { return this.images; }
            set { this.images = value; }
        }

        public virtual ICollection<ChatMessage> ChatMessages
        {
            get { return this.messages; }
            set { this.messages = value; }
        }
    }
}
