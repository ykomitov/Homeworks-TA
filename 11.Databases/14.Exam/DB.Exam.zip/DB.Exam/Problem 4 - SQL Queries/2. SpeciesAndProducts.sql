USE PetStore

SELECT s.Name AS 'Species', COUNT(p.ProductId) AS 'Number of Products'
FROM dbo.Species s
JOIN dbo.SpeciesProducts sp ON s.SpeciesId = sp.SpeciesId
JOIN dbo.PetProducts p ON sp.ProductId = p.ProductId
GROUP BY s.Name
ORDER BY 'Number of Products'