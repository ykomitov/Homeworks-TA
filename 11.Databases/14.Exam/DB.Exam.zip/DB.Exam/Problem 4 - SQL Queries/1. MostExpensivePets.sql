USE PetStore

SELECT TOP 5 p.Breed, p.Price, p.Birthday
FROM Pets p
WHERE p.Birthday >= '2012-01-01'
ORDER BY p.Price DESC