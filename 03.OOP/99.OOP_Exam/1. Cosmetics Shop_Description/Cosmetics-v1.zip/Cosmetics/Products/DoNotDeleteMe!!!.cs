﻿namespace Cosmetics.Products
{
    public class DoNotDeleteMe
    {
        // DO NOT DELETE THIS CLASS! IT IS IMPORTANT AND IT SERVES AN IMPORTANT ROLE!!!
        // Seriously, put all your classes in this namespace and delete this class...
    }
}
