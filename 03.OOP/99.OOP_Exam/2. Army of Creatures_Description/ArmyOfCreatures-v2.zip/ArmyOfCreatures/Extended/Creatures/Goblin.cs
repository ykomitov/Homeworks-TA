﻿namespace ArmyOfCreatures.Extended.Creatures
{
    using ArmyOfCreatures.Logic.Creatures;

    class Goblin : Creature
    {
        public Goblin()
            : base(4, 2, 5, 1.5M)
        {
        }
    }
}
