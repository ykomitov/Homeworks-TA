﻿
namespace Teleimot.WebApi.Tests.Setups
{
    using Data.Models;
    using Teleimot.Data.Repositories;
    using Moq;
    using System.Collections.Generic;
    using System.Linq;
    using System;

    public static class Repositories
    {
        public static IRepository<Comment> GetCommentsRepository()
        {
            var repository = new Mock<IRepository<Comment>>();

            repository.Setup(r => r.All()).Returns(() =>
            {
                return new List<Comment>
                {
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser1" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser2" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser4" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser3" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser1" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser2" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser4" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser3" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser1" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser2" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser4" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser3" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser1" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser2" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser4" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser3" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser1" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser2" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser4" }},
                    new Comment { Content = "Some content, man", CreatedOn = DateTime.Now, User = new User { UserName = "TestUser3" }},
                }.AsQueryable();
            });

            return repository.Object;
        }
    }
}
