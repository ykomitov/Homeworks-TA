﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teleimot.Services.Data;
using Teleimot.Services.Data.Contracts;

namespace Teleimot.WebApi.Tests.Setups
{
    public static class Services
    {
        public static ICommentsService GetCommentsService()
        {
            return new CommentsService(Repositories.GetCommentsRepository());
        }
    }
}
