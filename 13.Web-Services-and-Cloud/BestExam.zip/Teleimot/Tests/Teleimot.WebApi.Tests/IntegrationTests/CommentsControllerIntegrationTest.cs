﻿
namespace Teleimot.WebApi.Tests.IntegrationTests
{
    using Models.Comments;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyTested.WebApi;
    using System.Net;
    using System.Net.Http;
    using System.Collections.Generic;
    using System.Linq;

    [TestClass]
    public class ScoresTests
    {
        private static IServerBuilder server;

        [ClassInitialize]
        public static void Init(TestContext testContext)
        {
            server = MyWebApi.Server().Starts<Startup>();
        }

        [TestMethod]
        public void CommentsShouldReturnUnaouthorizedErrorWhitoutUser()
        {
            server
                .WithHttpRequestMessage(req => req
                    .WithMethod(HttpMethod.Get)
                    .WithRequestUri("/api/Comments/ByUser/TestUser1"))
                .ShouldReturnHttpResponseMessage()
                .WithStatusCode(HttpStatusCode.Unauthorized);
        }

        [ClassCleanup]
        public static void Clean()
        {
            MyWebApi.Server().Stops();
        }
    }
}
