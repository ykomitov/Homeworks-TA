﻿
namespace Teleimot.WebApi.Tests.ControllersTests
{
    using Controllers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Teleimot.WebApi.Tests.Setups;
    using MyTested.WebApi;
    using Models.Comments;
    using System.Collections.Generic;
    using Common.Constants;

    [TestClass]
    public class CommentsControllerTests
    {
        [TestMethod]
        public void GetShouldHaveAuthorizedAttribute()
        {
            MyWebApi
                .Controller<CommentsController>()
                .WithResolvedDependencyFor(Services.GetCommentsService())
                .Calling(c => c.GetByUser("Some user"))
                .ShouldHave()
                .ActionAttributes(attr => attr.RestrictingForAuthorizedRequests());
        }

        [TestMethod]
        public void GetShouldReturnOkWithProperResponse()
        {
            MyWebApi
                .Controller<CommentsController>()
                .WithResolvedDependencyFor(Services.GetCommentsService())
                .Calling(c => c.GetByUser("TestUser1"))
                .ShouldReturn()
                .Ok()
                .WithResponseModelOfType<List<CommentResponseModel>>()
                .Passing(pr => pr.Count == 5);
        }
    }
}
