﻿namespace Teleimot.WebApi.Tests.RouteTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Controllers;
    using System.Web.Http;
    using MyTested.WebApi;

    [TestClass]
    public class CommentsControllerRouteTests
    {
        [TestMethod]
        public void GetByUserShouldMapToCorrectActionWithDefaultSkipAndPage()
        {
            MyWebApi
                .Routes()
                .ShouldMap("/api/Comments/ByUser/SomeUser")
                .To<CommentsController>(c => c.GetByUser("SomeUser"));
        }

        [TestMethod]
        public void GetByUserShouldMapToCorrectActionWithProvidedCustomSkip()
        {
            MyWebApi
                .Routes()
                .ShouldMap("/api/Comments/ByUser/SomeUser?skip=2")
                .To<CommentsController>(c => c.GetByUser("SomeUser"));
        }

        [TestMethod]
        public void GetByUserShouldMapToCorrectActionWithProvidedCustomTake()
        {
            MyWebApi
                .Routes()
                .ShouldMap("/api/Comments/ByUser/SomeUser?take=5")
                .To<CommentsController>(c => c.GetByUser("SomeUser"));
        }

        [TestMethod]
        public void GetByUserShouldMapToCorrectActionWithProvidedCustomSkipAndTake()
        {
            MyWebApi
                .Routes()
                .ShouldMap("/api/Comments/ByUser/SomeUser?skip=2&take=5")
                .To<CommentsController>(c => c.GetByUser("SomeUser"));
        }

        [TestMethod]
        public void GetByUserShouldHaveInvalidModelStateIfUserNameIsNotProvided()
        {
            MyWebApi
                .Routes()
                .ShouldMap("/api/Comments/ByUser")
                .ToInvalidModelState(1);
        }
    }
}
