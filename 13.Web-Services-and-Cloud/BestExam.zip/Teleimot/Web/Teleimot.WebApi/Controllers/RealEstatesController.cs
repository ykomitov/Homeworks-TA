﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Teleimot.Common.Constants;
using Teleimot.Data.Models;
using Teleimot.Services.Data.Contracts;

using Microsoft.AspNet.Identity;

using AutoMapper;
using AutoMapper.QueryableExtensions;
using Teleimot.WebApi.Models.RealEstates;
using Teleimot.WebApi.Infrastructure.Validation;

namespace Teleimot.WebApi.Controllers
{
    public class RealEstatesController : ApiController
    {
        private IRealEstateService realEstates;

        public RealEstatesController(IRealEstateService realEstates)
        {
            this.realEstates = realEstates;
        }

        [HttpGet]
        public IHttpActionResult Get(string skip, string take)
        {
            int skipInt;
            int takeInt;
            if (!int.TryParse(skip, out skipInt))
            {
                skipInt = GlobalConstants.DefaultSkipCount;
            }

            if (!int.TryParse(take, out takeInt))
            {
                takeInt = GlobalConstants.DefaultTakeCount;
            }

            if (takeInt > GlobalConstants.MaxTakeCount)
            {
                takeInt = GlobalConstants.MaxTakeCount;
            }

            var result = this.realEstates.GetPublicEstates(skipInt, takeInt)
                .ProjectTo<PublicRealEstateResponseModel>()
                .ToList();

            return Ok(result);
        }

        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            var userId = this.User.Identity.GetUserId();
            if (userId != null)
            {
                var result = this.realEstates.GetRealEstateDetails(id)
                    .ProjectTo<PrivateDetailsRealEstateResponseModel>()
                    .FirstOrDefault();

                return Ok(result);
            }
            else
            {
                var result = this.realEstates.GetRealEstateDetails(id)
                    .ProjectTo<PublicDetailsRealEstateResponseModel>()
                    .FirstOrDefault();

                return Ok(result);
            }
        }

        [HttpPost]
        [Authorize]
        [ValidateModel]
        public IHttpActionResult Post(RealEstateRequestModel model)
        {
            // validate for the two bool properties
            if (model.SellingPrice == null && model.RentingPrice == null)
            {
                return BadRequest("You cannot publish a real estate ad that is not available for renting or buying.");
            }

            var userId = this.User.Identity.GetUserId();

            var result = this.realEstates.PublishAd(
                                            userId, model.Address, model.ConstructionYear, model.Contact, model.Description,
                                            model.RentingPrice, model.SellingPrice, model.Title, model.Type)
                                            .ProjectTo<PublicRealEstateResponseModel>()
                                            .FirstOrDefault();

            string location = Request.RequestUri.ToString();
            return Created(location, result);
        }
    }
}
