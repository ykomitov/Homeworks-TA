﻿namespace Teleimot.WebApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web;
    using System.Web.UI;
    using System.Web.Http;
    using Teleimot.Common.Constants;
    using Teleimot.Data.Models;
    using Teleimot.Services.Data.Contracts;
    using AutoMapper.QueryableExtensions;
    using AutoMapper;
    using Teleimot.WebApi.Models.Comments;
    using Teleimot.WebApi.Infrastructure.Validation;

    using Microsoft.AspNet.Identity;

    public class CommentsController : ApiController
    {
        private ICommentsService comments;

        public CommentsController(ICommentsService comments)
        {
            this.comments = comments;
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult Get(int id)
        {
            var querystring = Request.GetQueryNameValuePairs()
                       .ToDictionary(kv => kv.Key, kv=> kv.Value);

             string skip = querystring.ContainsKey("skip") ? querystring["skip"] : null;
             string take = querystring.ContainsKey("take") ? querystring["take"] : null;

             int skipInt;
             int takeInt;
             if (!int.TryParse(skip, out skipInt))
             {
                 skipInt = GlobalConstants.DefaultSkipCount;
             }

             if (!int.TryParse(take, out takeInt))
             {
                 takeInt = GlobalConstants.DefaultTakeCount;
             }

             if (takeInt > GlobalConstants.MaxTakeCount)
             {
                 takeInt = GlobalConstants.MaxTakeCount;
             }

            var result = this.comments.GetCommentsForAd(id, skipInt, takeInt)
                .ProjectTo<CommentResponseModel>()
                .ToList();

            return Ok(result);
        }

        [HttpGet]
        [Authorize]
        [ValidateModel]
        [Route("api/Comments/ByUser/{username}")]
        public IHttpActionResult GetByUser(string username)
        {
            var querystring = Request.GetQueryNameValuePairs()
                       .ToDictionary(kv => kv.Key, kv => kv.Value);

            string skip = querystring.ContainsKey("skip") ? querystring["skip"] : null;
            string take = querystring.ContainsKey("take") ? querystring["take"] : null;

            int skipInt;
            int takeInt;
            if (!int.TryParse(skip, out skipInt))
            {
                skipInt = GlobalConstants.DefaultSkipCount;
            }

            if (!int.TryParse(take, out takeInt))
            {
                takeInt = GlobalConstants.DefaultTakeCount;
            }

            if (takeInt > GlobalConstants.MaxTakeCount)
            {
                takeInt = GlobalConstants.MaxTakeCount;
            }

            var result = this.comments.GetCommentsFromUser(username, skipInt, takeInt)
                .ProjectTo<CommentResponseModel>()
                .ToList();

            return Ok(result);
        }

        [HttpPost]
        [Authorize]
        [ValidateModel]
        public IHttpActionResult Post(CommentRequestModel model)
        {
            var userId = this.User.Identity.GetUserId();

            Comment createdComment = this.comments.PostComment(userId, model.RealEstateId, model.Content);

            var result = this.comments.GetCommentDetails(createdComment.Id)
                .ProjectTo<CommentResponseModel>()
                .FirstOrDefault();

            string location = Request.RequestUri.ToString();
            return Created(location, result);
        }
    }
}
