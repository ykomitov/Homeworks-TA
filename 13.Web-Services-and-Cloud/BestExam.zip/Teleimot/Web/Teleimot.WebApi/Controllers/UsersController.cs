﻿
namespace Teleimot.WebApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using Teleimot.Data.Models;
    using Teleimot.Services.Data.Contracts;
    using Microsoft.AspNet.Identity;

    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using Teleimot.WebApi.Models.Users;
    using Teleimot.WebApi.Infrastructure.Validation;

    using TopUsersService;

    public class UsersController : ApiController
    {
        private IUsersService users;
        private TopUsersServiceClient wcfUsers;

        public UsersController(IUsersService users)
        {
            this.users = users;
            this.wcfUsers = new TopUsersServiceClient();
        }

        [HttpGet]
        [Route("api/users/{username}")]
        public IHttpActionResult Get(string username)
        {
            var result = this.users.GetUserDetails(username)
                .ProjectTo<UserResponseModel>()
                .FirstOrDefault();

            return Ok(result);
        }

        // To run this follow the post from user kidroca if it does not work, because there might be problems with localhost port numbers
        // https://telerikacademy.com/Forum/Questions/182791/%D0%9F%D1%80%D0%B5%D0%BC%D0%B0%D1%85%D0%B2%D0%B0%D0%BD%D0%B5-%D0%BD%D0%B0-Service-svc-%D0%BE%D1%82-%D0%BB%D0%B8%D0%BD%D0%BA%D0%BE%D0%B2%D0%B5-%D0%BD%D0%B0-WCF-services
        // Route = api/users/top.svc/
        [HttpGet]
        [Route("api/users/top.svc")]
        public IHttpActionResult Get()
        {
            var result = this.wcfUsers.GetTopUsers();

            return Ok(result);
        }

        [HttpPut]
        [Authorize]
        [Route("api/Users/Rate")]
        [ValidateModel]
        public IHttpActionResult Put(RateUserRequestModel model)
        {
            var userId = this.User.Identity.GetUserId();
            if (userId == model.UserId)
            {
                return BadRequest("You cannot rate yourself, you sly fox :)");
            }

            bool userExist = this.users.RateUser(model.UserId, model.Value);
            if (!userExist)
            {
                return BadRequest("No such user exists.");
            }

            return Ok();
        }
    }
}
