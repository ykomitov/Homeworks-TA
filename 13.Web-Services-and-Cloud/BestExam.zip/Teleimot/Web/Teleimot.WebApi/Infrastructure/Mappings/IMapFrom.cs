﻿namespace Teleimot.WebApi.Infrastructure.Mappings
{
    public interface IMapFrom<T>
    {
    }
}