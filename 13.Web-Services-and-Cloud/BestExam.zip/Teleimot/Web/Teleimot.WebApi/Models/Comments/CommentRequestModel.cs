﻿namespace Teleimot.WebApi.Models.Comments
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web;
    using Teleimot.Common.Constants;

    public class CommentRequestModel
    {
        public int RealEstateId { get; set; }

        [Required]
        [MinLength(GlobalConstants.CommentContentMinLength)]
        [MaxLength(GlobalConstants.CommentContentMaxLength)]
        public string Content { get; set; }
    }
}