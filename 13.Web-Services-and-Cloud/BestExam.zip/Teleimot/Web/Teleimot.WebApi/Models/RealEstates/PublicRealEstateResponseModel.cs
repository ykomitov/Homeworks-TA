﻿
namespace Teleimot.WebApi.Models.RealEstates
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using Teleimot.Data.Models;
    using Teleimot.WebApi.Infrastructure.Mappings;

    public class PublicRealEstateResponseModel : IMapFrom<RealEstate>, IHaveCustomMappings
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public decimal? SellingPrice { get; set; }

        public decimal? RentingPrice { get; set; }

        public bool CanBeSold { get; set; }

        public bool CanBeRented { get; set; }

        public void CreateMappings(IConfiguration configuration)
        {
            configuration.CreateMap<RealEstate, PublicRealEstateResponseModel>();
        }
    }
}