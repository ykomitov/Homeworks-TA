﻿
namespace Teleimot.WebApi.Models.RealEstates
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using Teleimot.WebApi.Infrastructure.Mappings;
    using Teleimot.Data.Models;
    using Teleimot.WebApi.Models.Comments;

    public class PrivateDetailsRealEstateResponseModel : IMapFrom<RealEstate>, IHaveCustomMappings
    {
        public string Contact { get; set; }

        public IEnumerable<CommentResponseModel> Comments { get; set; }

        public DateTime CreatedOn { get; set; }

        public int ConstructionYear { get; set; }

        public string Address { get; set; }

        public string RealEstateType { get; set; }

        public string Description { get; set; }

        public int Id { get; set; }

        public string Title { get; set; }

        public decimal? SellingPrice { get; set; }

        public decimal? RentingPrice { get; set; }

        public bool CanBeSold { get; set; }

        public bool CanBeRented { get; set; }

        public void CreateMappings(IConfiguration configuration)
        {
            configuration.CreateMap<RealEstate, PrivateDetailsRealEstateResponseModel>()
                .ForMember(e => e.RealEstateType, opts => opts.MapFrom(e => e.RealEstateType.ToString()));
        }
    }
}