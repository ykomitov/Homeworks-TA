﻿
namespace Teleimot.WebApi.Models.RealEstates
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web;
    using Teleimot.Common.Constants;

    public class RealEstateRequestModel
    {
        [Required]
        [MinLength(GlobalConstants.RealEstateTitleMinLength)]
        [MaxLength(GlobalConstants.RealEstateTitleMaxLength)]
        public string Title { get; set; }

        [Required]
        [MinLength(GlobalConstants.RealEstateDescritpionMinLength)]
        [MaxLength(GlobalConstants.RealEstateDescritpionMaxLength)]
        public string Description { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string Contact { get; set; }

        [Range(GlobalConstants.RealEstateYearMinValue, int.MaxValue)]
        public int ConstructionYear { get; set; }

        public decimal? SellingPrice { get; set; }

        public decimal? RentingPrice { get; set; }

        // there is a possibillity the type is null, at least that is what you see in the word file example for private real estate details response
        public int? Type { get; set; }
    }
}