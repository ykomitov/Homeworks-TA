﻿namespace Teleimot.WebApi.Models.Users
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web;
    using Teleimot.Common.Constants;

    public class RateUserRequestModel
    {
        [Required]
        public string UserId { get; set; }

        [Range(GlobalConstants.MinRatingValue, GlobalConstants.MaxRatingValue)]
        public int Value { get; set; }
    }
}