﻿
namespace Teleimot.WebApi.Models.Users
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using Teleimot.Data.Models;
    using Teleimot.WebApi.Infrastructure.Mappings;

    public class UserResponseModel : IMapFrom<User>, IHaveCustomMappings
    {
        public string UserName { get; set; }

        public int RealEstates { get; set; }

        public int Comments { get; set; }

        public double Rating { get; set; }

        public void CreateMappings(AutoMapper.IConfiguration configuration)
        {
            configuration.CreateMap<User, UserResponseModel>()
                 .ForMember(u => u.Comments, opts => opts.MapFrom(u => u.Comments.Count));
        }
    }
}