﻿
namespace Teleimot.Wcf
{
    using Teleimot.Data.Models;
    using Teleimot.Data.Repositories;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using Teleimot.Data;

    public abstract class BaseService // this class will be inherited by he service we need to do.
    {
        protected BaseService()
        {
            this.Users = new GenericRepository<User>(new TeleimotDbContext());
        }

        protected IRepository<User> Users { get; private set; }
    }
}