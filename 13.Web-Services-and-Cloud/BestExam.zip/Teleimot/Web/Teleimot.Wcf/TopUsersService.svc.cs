﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Teleimot.Common.Constants;
using Teleimot.Wcf.Models;

namespace Teleimot.Wcf
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "TopUsersService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select TopUsersService.svc or TopUsersService.svc.cs at the Solution Explorer and start debugging.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class TopUsersService : BaseService, ITopUsersService
    {
        // To run this follow the post from user kidroca if it does not work, because there might be problems with localhost port numbers
        // https://telerikacademy.com/Forum/Questions/182791/%D0%9F%D1%80%D0%B5%D0%BC%D0%B0%D1%85%D0%B2%D0%B0%D0%BD%D0%B5-%D0%BD%D0%B0-Service-svc-%D0%BE%D1%82-%D0%BB%D0%B8%D0%BD%D0%BA%D0%BE%D0%B2%D0%B5-%D0%BD%D0%B0-WCF-services
        // Route = api/users/top.svc/ and starting the WebApi project, not this one.
        public IEnumerable<WcfUserResponseModel> GetTopUsers()
        {
            var response = this.Users.All()
                .OrderByDescending(u => u.Rating)
                .Skip(GlobalConstants.DefaultSkipCount)
                .Take(GlobalConstants.DefaultTakeCount)
                .Select(u => new WcfUserResponseModel 
                {
                    Name = u.UserName,
                    Rating = u.Rating
                })
                .ToList();

            return response;
        }
    }
}
