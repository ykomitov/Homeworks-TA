﻿namespace Teleimot.Common.Constants
{
    public class Assemblies
    {
        public const string WebApi = "Teleimot.WebApi";

        public const string DataServices = "Teleimot.Services.Data";
    }
}
