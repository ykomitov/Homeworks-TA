﻿namespace Teleimot.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Common.Constants;

    public class RealEstate
    {
        private ICollection<Comment> comments;

        public RealEstate()
        {
            this.comments = new HashSet<Comment>();
        }

        public int Id { get; set; }

        [Required]
        [MinLength(GlobalConstants.RealEstateTitleMinLength)]
        [MaxLength(GlobalConstants.RealEstateTitleMaxLength)]
        public string Title { get; set; }

        [Required]
        [MinLength(GlobalConstants.RealEstateDescritpionMinLength)]
        [MaxLength(GlobalConstants.RealEstateDescritpionMaxLength)]
        public string Description { get; set; }

        // there is a possibillity the type is null, at least that is what you see in the word file example for private real estate details response
        public RealEstateType? RealEstateType { get; set; }

        [Range(GlobalConstants.RealEstateYearMinValue, int.MaxValue)]
        public int ConstructionYear { get; set; }

        [Required]
        public string Address { get; set; }

        public decimal? SellingPrice { get; set; }

        public decimal? RentingPrice { get; set; }

        public bool CanBeSold { get; set; }

        public bool CanBeRented { get; set; }

        [Required]
        public string Contact { get; set; }

        public DateTime CreatedOn { get; set; }

        public string UserId { get; set; }

        public virtual User User { get; set; }

        public virtual ICollection<Comment> Comments
        {
            get { return this.comments; }
            set { this.comments = value; }
        }
    }
}
