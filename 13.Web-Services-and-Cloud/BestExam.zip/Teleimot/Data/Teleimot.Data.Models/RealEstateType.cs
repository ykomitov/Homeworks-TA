﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teleimot.Data.Models
{
    public enum RealEstateType
    {
        Apartment = 0,
        House = 1,
        Office = 2,
        Storehouse = 3
    }
}
