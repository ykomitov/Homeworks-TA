﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teleimot.Common.Constants;

namespace Teleimot.Data.Models
{
    public class Comment
    {
        public int Id { get; set; }

        [Required]
        [MinLength(GlobalConstants.CommentContentMinLength)]
        [MaxLength(GlobalConstants.CommentContentMaxLength)]
        public string Content { get; set; }

        public DateTime CreatedOn { get; set; }

        public string UserId { get; set; }

        public virtual User User { get; set; }

        public int RealEstateId { get; set; }

        public virtual RealEstate RealEstate { get; set; }
    }
}
