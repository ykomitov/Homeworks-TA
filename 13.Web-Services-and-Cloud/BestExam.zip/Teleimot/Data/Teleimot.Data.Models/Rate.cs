﻿
namespace Teleimot.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Common.Constants;

    public class Rate
    {
        public int Id { get; set; }

        [Range(GlobalConstants.MinRatingValue, GlobalConstants.MaxRatingValue)]
        public int Value { get; set; }

        [Required]
        public string UserId { get; set; }

        public virtual User User { get; set; }
    }
}
