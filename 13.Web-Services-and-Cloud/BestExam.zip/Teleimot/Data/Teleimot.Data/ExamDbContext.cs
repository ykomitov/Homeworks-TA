﻿namespace Teleimot.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using Teleimot.Data.Models;
    using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;

    public class TeleimotDbContext : IdentityDbContext<User>
    {
        public TeleimotDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public virtual DbSet<RealEstate> RealEstates { get; set; }

        public virtual DbSet<Comment> Comments { get; set; }

        public virtual DbSet<Rate> Ratings { get; set; }

        public static TeleimotDbContext Create()
        {
            return new TeleimotDbContext();
        }
    }
}
