﻿namespace Teleimot.Services.Data.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Data.Models;

    public interface IUsersService
    {

        IQueryable<User> GetUserDetails(string userName);

        bool RateUser(string userId, int rateValue);
    }
}
