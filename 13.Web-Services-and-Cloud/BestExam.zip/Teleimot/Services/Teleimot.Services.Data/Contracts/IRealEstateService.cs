﻿
namespace Teleimot.Services.Data.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Data.Models;

    public interface IRealEstateService
    {
        IQueryable<RealEstate> GetPublicEstates(int skipInt, int takeInt);

        IQueryable<RealEstate> GetRealEstateDetails(int realEstateId);

        IQueryable<RealEstate> PublishAd(
            string userId, string address, int constructionYear, string contact,
            string description, decimal? rentingPrice, decimal? sellingPrice, string title, int? type);
    }
}
