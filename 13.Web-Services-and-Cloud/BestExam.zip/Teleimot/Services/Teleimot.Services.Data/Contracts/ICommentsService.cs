﻿
namespace Teleimot.Services.Data.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Data.Models;


    public interface ICommentsService
    {
        IQueryable<Comment> GetCommentsForAd(int realEstateId, int skipInt, int takeInt);

        IQueryable<Comment> GetCommentsFromUser(string username, int skipInt, int takeInt);

        Comment PostComment(string userId, int realEstateId, string content);

        IQueryable<Comment> GetCommentDetails(int id);
    }
}
