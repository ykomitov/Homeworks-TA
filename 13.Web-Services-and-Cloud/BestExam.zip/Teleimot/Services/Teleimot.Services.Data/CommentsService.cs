﻿namespace Teleimot.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Data.Models;
    using Teleimot.Data.Repositories;
    using Teleimot.Services.Data.Contracts;

    public class CommentsService : ICommentsService
    {
        private IRepository<Comment> comments;

        public CommentsService(IRepository<Comment> comments)
        {
            this.comments = comments;
        }

        public IQueryable<Comment> GetCommentsForAd(int realEstateId, int skipInt, int takeInt)
        {
            var result = this.comments.All()
                .Where(c => c.RealEstateId == realEstateId)
                .OrderBy(c => c.CreatedOn)
                .Skip(skipInt)
                .Take(takeInt);

            return result;
        }

        public IQueryable<Comment> GetCommentsFromUser(string username, int skipInt, int takeInt)
        {
            var result = this.comments.All()
                .Where(c => c.User.UserName == username)
                .OrderBy(c => c.CreatedOn)
                .Skip(skipInt)
                .Take(takeInt);

            return result;
        }

        public Comment PostComment(string userId, int realEstateId, string content)
        {
            var newComment = new Comment 
            {
                Content = content,
                CreatedOn = DateTime.Now,
                RealEstateId = realEstateId,
                UserId = userId
            };

            this.comments.Add(newComment);
            this.comments.SaveChanges();

            return newComment;
        }

        public IQueryable<Comment> GetCommentDetails(int id)
        {
            return this.comments.All()
                .Where(c => c.Id == id);
        }
    }
}
