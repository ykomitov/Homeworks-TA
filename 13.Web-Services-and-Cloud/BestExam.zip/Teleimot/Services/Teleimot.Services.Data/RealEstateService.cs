﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teleimot.Data.Models;
using Teleimot.Data.Repositories;
using Teleimot.Services.Data.Contracts;

namespace Teleimot.Services.Data
{
    public class RealEstateService : IRealEstateService
    {
        private IRepository<RealEstate> realEstates;
        private IRepository<User> users;

        public RealEstateService(IRepository<RealEstate> realEstates, IRepository<User> users)
        {
            this.realEstates = realEstates;
            this.users = users;
        }

        public IQueryable<RealEstate> GetPublicEstates(int skipInt, int takeInt)
        {
            var response = this.realEstates.All()
                .OrderByDescending(e => e.CreatedOn)
                .Skip(skipInt)
                .Take(takeInt);

            return response;
        }

        public IQueryable<RealEstate> GetRealEstateDetails(int realEstateId)
        {
            var result = this.realEstates.All()
                .Where(e => e.Id == realEstateId);

            return result;

        }


        public IQueryable<RealEstate> PublishAd(
            string userId, string address, int constructionYear, string contact,
            string description, decimal? rentingPrice, decimal? sellingPrice, string title, int? type)
        {
            var newRealEstate = new RealEstate
            {
                Address = address,
                CanBeRented = rentingPrice == null ? false : true,
                CanBeSold = sellingPrice == null ? false : true,
                ConstructionYear = constructionYear,
                Contact = contact,
                CreatedOn = DateTime.Now,
                Description = description,
                RealEstateType = (RealEstateType?)(type),
                RentingPrice = rentingPrice,
                SellingPrice = sellingPrice,
                Title = title,
                UserId = userId
            };

            this.realEstates.Add(newRealEstate);
            this.realEstates.SaveChanges();

            var user = this.users.GetById(userId);
            user.RealEstates++;
            this.users.SaveChanges();

            return new List<RealEstate> { newRealEstate }
                                        .AsQueryable();
        }
    }
}
