﻿namespace Teleimot.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Teleimot.Data.Models;
    using Teleimot.Data.Repositories;
    using Teleimot.Services.Data.Contracts;

    public class UsersService : IUsersService
    {
        private IRepository<User> users;
        private IRepository<Rate> ratings;

        public UsersService(IRepository<User> users, IRepository<Rate> ratings)
        {
            this.users = users;
            this.ratings = ratings;
        }

        public IQueryable<User> GetUserDetails(string userName)
        {
            return this.users.All()
                .Where(u => u.UserName == userName);
        }


        public bool RateUser(string userId, int rateValue)
        {
            var user = this.users.GetById(userId);

            if (user == null)
            {
                return false;
            }

            var rate = new Rate
            {
                UserId = userId,
                Value = rateValue
            };

            this.ratings.Add(rate);
            this.ratings.SaveChanges();

            user.Rating = user.Ratings.Average(r => r.Value);

            this.users.SaveChanges();

            return true;
        }
    }
}
