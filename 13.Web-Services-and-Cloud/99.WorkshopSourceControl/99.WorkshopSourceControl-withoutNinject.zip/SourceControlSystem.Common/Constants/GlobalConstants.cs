﻿namespace SourceControlSystem.Common.Constants
{
    public class GlobalConstants
    {
        public const int DefaultPageSize = 10;
    }
}
