﻿using System;
using System.Numerics;
    class IntegerCalculations
    {
        static void Main()
        {
            
   // Write methods to calculate minimum, maximum, average, sum and product of given set of integer numbers.
   // Use variable number of arguments.

            Console.WriteLine("Please enter the set of integers separated by space");
            string[] input = Console.ReadLine().Split(' ');
            int []numbers=new int[input.Length];
            for (int i = 0; i <input.Length; i++)
            {
                numbers[i] = int.Parse(input[i]);
            }
            Console.WriteLine("Minimum:{0}",MinNumber(numbers));
            Console.WriteLine("Maximum:{0}",MaxNumber(numbers));
            Console.WriteLine("Sum:{0}", Sum(numbers));
            Console.WriteLine("Average:{0}", Average(numbers));
            Console.WriteLine("Product:{0}", Product(numbers));

        }
        static int Sum(int[] a)
        {
            int sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                sum = sum + a[i];
            }
            return sum;
        }
        static decimal Average(int[] a)
        {
            int sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                sum = sum + a[i];
            }
            return (decimal)sum/a.Length;
        }
        static BigInteger Product(int[] a)
        {
            BigInteger product = 1;
            for (int i = 0; i < a.Length; i++)
            {
                product = product*a[i];
            }
            return product;
        }
        static int MaxNumber(int[] a)
        {
            int max = a[0];
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > max)
                {
                    max = a[i];
                }

            }
            return max;
        }
        static int MinNumber(int[] a)
        {
            int min = a[0];
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] < min)
                {
                    min = a[i];
                }

            }
            return min;
        }
    }

