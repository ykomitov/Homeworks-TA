﻿using System;

class AppearanceCount
{
    
  //  Write a method that counts how many times given number appears in given array.
  //  Write a test program to check if the method is workings correctly.

    static int AppearanceCounter(int[] a, int n)
    {
        int i = 0;
        int counter = 0;
        while (i < a.Length)
        {
            if (a[i] == n)
            {
                counter++;

            }
            i++;
        }
        return counter;
    }
    static void Main()
    {
        Console.WriteLine("Please enter the elements of the array on a single line separated by space");
        string[] numbersAsString = Console.ReadLine().Split(' ');
        Console.WriteLine("Please enter the number to search for");
        int number = int.Parse(Console.ReadLine());
        int[] numbers = new int[numbersAsString.Length];
        for (int i = 0; i < numbersAsString.Length; i++)
        {
            numbers[i] = int.Parse(numbersAsString[i]);

        }
        Console.WriteLine("Number {0} appears {1} times in the given array!", number, AppearanceCounter(numbers, number));


    }
}

