﻿using System;
using System.Text;

    class ReverseNumber
    {
       // Write a method that reverses the digits of given decimal number.
        static decimal NumberReverse(decimal n)
        {
            string numberAsString = n.ToString();
            StringBuilder reversed=new StringBuilder();
            decimal reversedNumber;

            for (int i = numberAsString.Length - 1; i >= 0; i--)
            {
                reversed.Append(numberAsString[i]);
            }
            
            reversedNumber = decimal.Parse(reversed.ToString());
            return reversedNumber;
        }

        static void Main()
        {
            decimal a = decimal.Parse(Console.ReadLine());
            if (a % 10 == 0)
            {
                Console.WriteLine("The number cannot be reversed because number cannot start with 0");
            }
            else
            {

                Console.WriteLine(NumberReverse(a));
            }
        }
    }

