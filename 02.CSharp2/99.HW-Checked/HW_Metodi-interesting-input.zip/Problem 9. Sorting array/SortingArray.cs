﻿using System;

class SortingArray
{
    static int MaxNumber(int[] a, int index)
    {
        
   // Write a method that return the maximal element in a portion of array of integers starting at given index.
   // Using it write another method that sorts an array in ascending / descending order.

        int max = a[index];
        for (int i = index + 1; i < a.Length; i++)
        {
            if (a[i] > max)
            {
                max = a[i];
            }

        }
        return max;
    }
    static int[] SortAscending(int[] numbers)
    {
        int swap = 0;
        for (int i = 0; i < numbers.Length; i++)
        {

            for (int j = i + 1; j < numbers.Length; j++)
            {

                if (numbers[i] > numbers[j])
                {


                    swap = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = swap;

                }

            }
        }
        return numbers;
    }
    static int[] SortDescending(int[] numbers)
    {
        int swap = 0;
        for (int i = 0; i < numbers.Length; i++)
        {

            for (int j = i + 1; j < numbers.Length; j++)
            {

                if (numbers[i] < numbers[j])
                {


                    swap = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = swap;

                }

            }
        }
        return numbers;
    }
    static void PrintArray(int[] numbers)
    {
        for (int i = 0; i < numbers.Length; i++)
        {
            Console.Write(i != numbers.Length - 1 ? "{0}," : "{0}", numbers[i]);
        }
        Console.WriteLine();
    }
    static void Main()
    {
        Console.WriteLine("Please enter the elements of the array on a single line separated by space");
        string[] numbersAsString = Console.ReadLine().Split(' ');
        Console.WriteLine("Please enter an index ");
        int[] numbers = new int[numbersAsString.Length];
        int index = int.Parse(Console.ReadLine());
        for (int i = 0; i < numbersAsString.Length; i++)
        {
            numbers[i] = int.Parse(numbersAsString[i]);

        }
        Console.WriteLine("The maximal element after index {0} is {1}", index, MaxNumber(numbers, index));
        Console.WriteLine("Array sorted ascending:");
        numbers = SortAscending(numbers);
        PrintArray(numbers);
        Console.WriteLine("Array sorted descending");
        numbers = SortDescending(numbers);
        PrintArray(numbers);
    }
}

