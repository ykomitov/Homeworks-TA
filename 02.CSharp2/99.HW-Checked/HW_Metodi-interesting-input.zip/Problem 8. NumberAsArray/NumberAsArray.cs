﻿using System;

class NumberAsArray
{
    static void Main()
    {
        
  //  Write a method that adds two positive integer numbers represented as arrays of digits (each array element arr[i] contains a digit; the last digit is kept in arr[0]).
  //  Each of the numbers that will be added could have up to 10 000 digits.

        Console.Write("First  number:");
        string inputFirst = Console.ReadLine();
        int[] firstArray = ArrayConvert(inputFirst);
        
        Console.Write("Second number:");
        string inputSecond = Console.ReadLine();
        int[] secondArray = ArrayConvert(inputSecond);
        int[] result = AddArray(firstArray, secondArray);
        
        Console.Write("Result number:");
        for (int i = 0; i <result.Length; i++)
        {
            Console.Write(result[i]);
        }
        Console.WriteLine();

    }
    static int[] ArrayConvert(string a)
    {
        int[] numbers=new int[a.Length];
        for (int i = 0; i < a.Length; i++)
        {
            numbers[a.Length - 1 - i] = int.Parse(a[i].ToString());
        }
        return numbers;
    }
    static int[] AddArray(int[] firstArray, int[] secondArray)
    {
        int length = Math.Max(firstArray.Length, secondArray.Length);
        int[] bigger = new int[length];
        int[] result = new int[length];
        int sum = 0;
        int add = 0;
        if (firstArray.Length > secondArray.Length)
        {
            bigger = firstArray;
        }
        else
        {
            bigger = secondArray;
        }

        for (int i = 0; i < length; i++)
        {
            if (i < Math.Min(firstArray.Length, secondArray.Length))
            {


                sum = (firstArray[i] + secondArray[i]) + add;
                if (sum > 9)
                {
                    add = sum / 10;
                    sum = sum % 10;

                }
                else
                {
                    add = 0;
                }

                result[length - 1 - i] = sum;
            }
            else
            {
                result[length - 1 - i] = bigger[i];
            }
        }
        return result;
    }
}

