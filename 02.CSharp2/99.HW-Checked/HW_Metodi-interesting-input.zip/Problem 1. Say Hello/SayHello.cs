﻿using System;

    class SayHello
    {
        
 //  Write a method that asks the user for his name and prints “Hello, <name>”
 //  Write a program to test this method.

        static void Name()
        {
            Console.WriteLine("Please enter your name");
            string n = Console.ReadLine();
            Console.WriteLine("Hello,{0}",n);
            
            
        }
        static void Main()
        {

            Name();
           
        }
    }

