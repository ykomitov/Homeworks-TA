﻿using System;

    class GetLargestNumber
    { 
      //  Write a method GetMax() with two parameters that returns the larger of two integers.
      //  Write a program that reads 3 integers from the console and prints the largest of them using the method GetMax()
        static int GetMax(int a, int b)
        {
            int max = 0;
            if (a > b)
            {
                max = a;
            }
            else
            {
                max = b;

            }
            return max;
        }
        static void Main()
        {

            Console.WriteLine("Please enter 3 numbers");
            int firstNumber = int.Parse(Console.ReadLine());
            int secondNumber = int.Parse(Console.ReadLine());
            int thirdNumber = int.Parse(Console.ReadLine());
            int max = GetMax(firstNumber, secondNumber);
            max = GetMax(max, thirdNumber);
            Console.WriteLine("The largest number is {0}",max);


        }
    }

