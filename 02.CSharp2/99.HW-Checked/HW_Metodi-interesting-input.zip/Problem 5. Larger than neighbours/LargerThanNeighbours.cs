﻿using System;

class LargerThanNeighbours
{
    static bool IsLarger(int[] a, int n)
    {
        
  //  Write a method that checks if the element at given position in given array of integers is larger than its two neighbours (when such exist).

        bool larger;
       
            if (a[n] > a[n - 1] && a[n] > a[n + 1])
            {
                larger = true;
            }
            else
            {
                larger = false;
            }
            return larger;
    }
    static void Main()
    {
        Console.WriteLine("Please enter the elements of the array on a single line separated by space");
        string[] numbersAsString = Console.ReadLine().Split(' ');
        Console.WriteLine("Please enter a index to check");
        int index = int.Parse(Console.ReadLine());
        int[] numbers = new int[numbersAsString.Length];
        for (int i = 0; i < numbersAsString.Length; i++)
        {
            numbers[i] = int.Parse(numbersAsString[i]);

        }
        if (index - 1 < 0 || index + 1 >= numbers.Length)
        {
            Console.WriteLine("The number at index {0} doesn't have two neighbours!", index);
        }
        else
        {
            Console.WriteLine("The number at index {0} is larger than its two neigbours - {1}",index,IsLarger(numbers,index));
        }
       

    }
}

