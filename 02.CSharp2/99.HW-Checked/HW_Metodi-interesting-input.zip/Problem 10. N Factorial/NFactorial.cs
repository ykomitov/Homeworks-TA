﻿using System;
using System.Numerics;

    class NFactorial
    {
       // Write a program to calculate n! for each n in the range [1..100].
    static BigInteger Factorial(int n)
    {
        BigInteger fact = 1;
        for (int i = 2; i <= n; i++)
        {
            fact = fact * i;
        }
        return fact;

    }
        static void Main()
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine("Number:{0}  Factorial:{1}",i,Factorial(i));
            }


        }
    }

