﻿using System;

class EnglishDigit
{
   // Write a method that returns the last digit of given integer as an English word.
    static string DigitAsWord(int n)
    {
        int lastDigit = n % 10;
        string digitInEnglish = string.Empty;
        switch (lastDigit)
        {
            case 1: digitInEnglish = "One"; break;
            case 2: digitInEnglish = "Two"; break;
            case 3: digitInEnglish = "Three"; break;
            case 4: digitInEnglish = "Four"; break;
            case 5: digitInEnglish = "Five"; break;
            case 6: digitInEnglish = "Six"; break;
            case 7: digitInEnglish = "Seven"; break;
            case 8: digitInEnglish = "Eight"; break;
            case 9: digitInEnglish = "Nine"; break;
            default: digitInEnglish = "Zero"; break;

        }
        return digitInEnglish;
    }
    static void Main()
    {
        Console.WriteLine("Please enter a number");
        int number = int.Parse(Console.ReadLine());
        string lastDigit = DigitAsWord(number);
        Console.WriteLine("The last digit is {0}", lastDigit);


    }
}

