﻿using System;
using System.Text;

class AddingPolynomials
{
    
  //  Write a method that adds two polynomials.
  //  Represent them as arrays of their coefficients.

    static void Main()
    {
        Console.WriteLine("Please enter polynomial as in the example- 2  x^2+5 y-7 =0");
        int[] firstPolynomial = PolynomialInput(1);
        int[] secondPolynomial = PolynomialInput(2);
        int[] resultPolynomial = AddPolynomial(firstPolynomial, secondPolynomial);
        Console.WriteLine("Result:");
        Console.Write("{0}x^2 {1}x {2}=0", resultPolynomial[0], resultPolynomial[1], resultPolynomial[2]);
        Console.WriteLine();
    }
    static int[] PolynomialInput(int row)
    {
        string[] x = new string[3];
        Console.Write("   x^2   x   =0");
        Console.SetCursorPosition(0, row);
        x[0] = Console.ReadLine();
        Console.SetCursorPosition(6, row);
        x[1] = Console.ReadLine();
        Console.SetCursorPosition(10, row);
        x[2] = Console.ReadLine();
        int[] input = new int[3];
        for (int i = 0; i < 3; i++)
        {
            input[3 - i - 1] = int.Parse(x[i]);

        }
        return input;
    }
    static int[] AddPolynomial(int[] firstArray, int[] secondArray)
    {
        int[] result = new int[3];

        for (int i = 0; i < 3; i++)
        {

            result[3 - i - 1] = (firstArray[i] + secondArray[i]);

        }
        return result;
    }
}

