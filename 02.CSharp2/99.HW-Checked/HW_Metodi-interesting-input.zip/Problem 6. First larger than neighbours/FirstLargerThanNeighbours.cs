﻿using System;

class FirstLargerThanNeighbours
{
    
  //  Write a method that returns the index of the first element in array that is larger than its neighbours, or -1, if there’s no such element.
  //  Use the method from the previous exercise.

    static int IndexOfFirstLarger(int[] a)
    {
        int indexOfLarger = 0; ;
        for (int i = 1; i < a.Length-1; i++)
        {
            if (a[i] > a[i - 1] && a[i] > a[i + 1])
            {
                indexOfLarger=i;
                break;
            }
            else
            {
                indexOfLarger = -1;
            }
        }
        return indexOfLarger;
    }
    static void Main()
    {
        Console.WriteLine("Please enter the elements of the array on a single line separated by space");
        string[] numbersAsString = Console.ReadLine().Split(' ');
        int[] numbers = new int[numbersAsString.Length];
        for (int i = 0; i < numbersAsString.Length; i++)
        {
            numbers[i] = int.Parse(numbersAsString[i]);

        }
        Console.WriteLine(IndexOfFirstLarger(numbers));

    }
}

