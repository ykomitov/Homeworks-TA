﻿using System;
using System.Text;

class SolveTasks
{
    static void Main()
    {
        
   // Write a program that can solve these tasks:
   //     Reverses the digits of a number
   //     Calculates the average of a sequence of integers
   //     Solves a linear equation a * x + b = 0
   // Create appropriate methods.
   // Provide a simple text-based menu for the user to choose which task to solve.
   // Validate the input data:
   //     The decimal number should be non-negative
   //     The sequence should not be empty
   //     a should not be equal to 0
   //
        Console.WriteLine("What do you want do?");
        Console.WriteLine("1.Reverse number- enter REVERSE");
        Console.WriteLine("2.Average of sequence of integers- enter AVERAGE");
        Console.WriteLine("3.Solve linear equation a * x + b = 0- enter LINEAR");
        string choice = Console.ReadLine();
        switch (choice)
        {
            case "REVERSE": ReverseNumber(); break;
            case "AVERAGE": Average(); break;
            case "LINEAR": Linear(); break;

        }

    }
    static void Average()
    {
        Console.WriteLine("Please enter a sequenve of integers separated by space");
        string input = Console.ReadLine();
        if (input.Length < 1)
        {
            Console.WriteLine("The sequence should not be empty");

        }


        else
        {
            string[] numbersAsString = input.Split(' ');
            int[] numbers = new int[numbersAsString.Length];
            int sum = 0;
            for (int i = 0; i < numbersAsString.Length; i++)
            {
                numbers[i] = int.Parse(numbersAsString[i]);
                sum = sum + numbers[i];
            }
            Console.WriteLine("The Average is : {0}", (double)sum / numbers.Length);
        }
    }
    static void ReverseNumber()
    {
        Console.WriteLine("Please enter a number");
        decimal number = decimal.Parse(Console.ReadLine());
        if (number % 10 == 0)
        {
            Console.WriteLine("The number cannot be reversed because number cannot start with 0");
        }
        else if (number < 0)
        {
            Console.WriteLine("The number cannot be negative");
        }
        else
        {


            string numberAsString = number.ToString();
            StringBuilder reversed = new StringBuilder();
            decimal reversedNumber;

            for (int i = numberAsString.Length - 1; i >= 0; i--)
            {
                reversed.Append(numberAsString[i]);
            }

            reversedNumber = decimal.Parse(reversed.ToString());
            Console.WriteLine("Reversed number:{0}", reversedNumber);
        }

    }
    static void Linear()
    {
        Console.WriteLine("Please enter fill the equation");
        decimal[] coefficients = LinearInput(6);
        if (coefficients[0] == 0)
        {
            Console.WriteLine("a should not be equal to 0");

        }
        else
        {
            decimal result = (-coefficients[1]) / coefficients[0];
            Console.Write("The result is x= {0}", result);
            Console.WriteLine();
        }
    }
    static decimal[] LinearInput(int row)
    {
        string[] x = new string[2];
        Console.Write("   x    =0");
        Console.SetCursorPosition(0, row);
        x[0] = Console.ReadLine();
        Console.SetCursorPosition(4, row);
        x[1] = Console.ReadLine();
        decimal[] input = new decimal[2];




        for (int i = 0; i < 2; i++)
        {
            input[i] = int.Parse(x[i]);


        }

        return input;

    }
}

